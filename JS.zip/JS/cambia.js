const mostra = document.getElementById("guarda");
const password = document.getElementById("password");

mostra.onclick = () => {
  vediPassword();
};
function vediPassword() {
  if (password.type === "password") {
    password.type = "text";
  } else {
    password.type = "password";
  }
}