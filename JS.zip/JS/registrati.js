function cripta(stringa) {
  let arrayASCII = [];
  let arrayProdotto = [];
  let criptata = "";
  for (let i = 0; i < stringa.length; i++) {
    arrayASCII.push(stringa.charCodeAt(i));
  }
  const codiceUnivoco = parseInt(arrayASCII[arrayASCII.length - 1], 10);
  for (let i = 0; i < stringa.length; i++) {
    if (parseInt(arrayASCII[i], 10) + codiceUnivoco > 255)
      arrayProdotto.push(parseInt(arrayASCII[i], 10) + codiceUnivoco - 255);
    else arrayProdotto.push(parseInt(arrayASCII[i], 10) + codiceUnivoco);
  }
  for (let i = 0; i < arrayProdotto.length; i++) {
    criptata += String.fromCharCode(arrayProdotto[i]);
  }
  return criptata;
}
const mostra = document.getElementById("guarda");
const password = document.getElementById("password");
const registrati = document.getElementById("registrati");
let mail = document.getElementById("email");
const nome = document.getElementById("nome");

registrati.onclick = () => {
 // if (controlloMail() && nome.value !== "")
    //password.value = cripta(password.value);
};

mostra.onclick = () => {
  vediPassword();
};
function vediPassword() {
  if (password.type === "password") {
    password.type = "text";
  } else {
    password.type = "password";
  }
}

function controlloMail() {
  // recupero il valore della email indicata nel form
  // se non ho inserito nulla nel campo
  console.log(password);
  if (mail.value === "") return false;
  // verifico se è un indirizzo valido
  if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail.value))
    return true;
  else return false;
}
