let dict = [];
const canvasTemperatura = document.getElementById("temperatura");
const ctxTemperatura = canvasTemperatura.getContext("2d");
const canvasUmidita = document.getElementById("umidita");
const ctxUmidita = canvasUmidita.getContext("2d");
const canvasPioggia = document.getElementById("pioggia");
const ctxPioggia = canvasPioggia.getContext("2d");
const bottoneTemperatura = document.getElementById("bottoneTemperatura");
const bottoneUmidita = document.getElementById("bottoneUmidita");
const bottoneHelp = document.getElementById("help");
const divHelp = document.getElementById("aiuto");
let boolTemperatura = false;
let boolUmidita = false;
const [, time] = formatDate(new Date()).split(" ");
const timeInput = document.getElementById("time");
timeInput.value = time;
const update = document.getElementById("update");
const controlImg = '<div class="carousel-item %CLASS" data-bs-interval="%SECONDI000">' + '<div class="row">' + '<div class="col">' + "<img " + 'src="http://serverfapakslapa.myddns.me/immaginiSalvate/immmagine%NUM1.jpg" ' + 'height="400" ' + 'class="d-block mx-auto" ' + 'aria-label="Placeholder: First slide" ' + 'preserveAspectRatio="xMidYMid slice" ' + 'focusable="false"  alt=""' + "/>" + "</div>" + '<div class="col">' + "<img " + 'src="http://serverfapakslapa.myddns.me/immaginiSalvate/immmagine%NUM2.jpg" ' + 'height="400" ' + 'class="d-block mx-auto" ' + 'preserveAspectRatio="xMidYMid slice" ' + 'focusable="false" alt=""' + "/>" + "</div>" + "</div>" + "</div>";
const caruselBody = '<div class="carousel-inner">%BODY</div>' + '<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="prev">' + '<span class="carousel-control-prev-icon" aria-hidden="true"></span>' + '<span class="visually-hidden">Previous</span>' + "</button>" + '<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="next">' + '<span class="carousel-control-next-icon" aria-hidden="true"></span>' + '<span class="visually-hidden">Next</span>' + "</button>";
let html = "";
const stringaAiuto = '<div class="toast fade show text-bg-dark">\n' +
    '<div class="toast-header text-bg-secondary">\n' +
    '<strong class="me-auto"\n' +
    '><i class="bi-globe"></i>Rilevazioni & Sensori</strong\n' +
    ">\n" +
    "<small>Istruzione uno</small>\n" +
    "<button\n" +
    'type="button"\n' +
    'class="btn-close"\n' +
    'data-bs-dismiss="toast"\n' +
    "></button>\n" +
    "</div>\n" +
    '<div class="toast-body">\n' +
    "Ossera i box con i dati per i sensori. <br />\n" +
    "Clicca sul pulsante con il controno blu per vedere i grafici.\n" +
    "</div>\n" +
    "</div>\n" +
    '<div class="toast fade show text-bg-dark">\n' +
    '<div class="toast-header text-bg-secondary">\n' +
    '<strong class="me-auto"\n' +
    '><i class="bi-globe"></i>Pagine Correlate</strong\n' +
    ">\n" +
    "<small>Istruzione due</small>\n" +
    "<button\n" +
    'type="button"\n' +
    'class="btn-close"\n' +
    'data-bs-dismiss="toast"\n' +
    "></button>\n" +
    "</div>\n" +
    '<div class="toast-body">\n' +
    "Clicca sul pulsante per uscire dal sito e vedere tutte le pagine del\n" +
    "progetto.\n" +
    "</div>\n" +
    "</div>\n" +
    '<div class="toast fade show text-bg-dark">\n' +
    '<div class="toast-header text-bg-secondary">\n' +
    '<strong class="me-auto"\n' +
    '><i class="bi-globe"></i>Impostazioni</strong\n' +
    ">\n" +
    "<small>Istruzione tre</small>\n" +
    "<button\n" +
    'type="button"\n' +
    'class="btn-close"\n' +
    'data-bs-dismiss="toast"\n' +
    "></button>\n" +
    "</div>\n" +
    '<div class="toast-body">\n' +
    "Dopo aver acceduto alla tua area personale potrai modificare le\n" +
    "impostazione per l'irrigazione.\n" +
    "</div>\n" +
    "</div>\n" +
    '<div class="toast fade show text-bg-dark">\n' +
    '<div class="toast-header text-bg-secondary">\n' +
    '<strong class="me-auto"><i class="bi-globe"></i>Reset</strong>\n' +
    "<small>Istruzione quattro</small>\n" +
    "<button\n" +
    'type="button"\n' +
    'class="btn-close"\n' +
    'data-bs-dismiss="toast"\n' +
    "></button>\n" +
    "</div>\n" +
    '<div class="toast-body">\n' +
    "Con il pulsante reset (<img\n" +
    'src="reset.svg"\n' +
    'alt=""\n' +
    'width="30"\n' +
    'height="24"\n' +
    'class="d-inline-block align-text-center"\n' +
    "/>) potrai eliminare ogni dato del tuo irrigatore\n" +
    "</div>\n" +
    "</div>" +
    '<div class="toast fade show text-bg-dark">\n' +
    '<div class="toast-header text-bg-secondary">\n' +
    '<strong class="me-auto"><i class="bi-globe"></i>Innaffia subito</strong>\n' +
    "<small>Istruzione cinque</small>\n" +
    "<button\n" +
    'type="button"\n' +
    'class="btn-close"\n' +
    'data-bs-dismiss="toast"\n' +
    "></button>\n" +
    "</div>\n" +
    '<div class="toast-body">\n' +
    "con il pulsante in basso a destra, potrai attivare immediatamente l'irrigatore <br>" +
    "La durata sarà come selezionato da impostazioni" +
    "</div>\n" +
    "</div>";

const divCarosello = document.getElementById("carouselExampleInterval");
const buttonIrriga = document.getElementById("innaffia");
const divReset = document.getElementById("resetBody");
const checkTemplate = '<div class="form-check">\n' +
    '  <input class="form-check-input" value="premuto" type="checkbox" value="" name="%NAME" id="%ID">\n' +
    '  <label class="form-check-label" for="%IDLABEL">\n' +
    '    %DESCRIZIONE\n' +
    '  </label>\n' +
    '</div>'

/**
 * Funzione per recuperare i dati delle rilevazioni meteo
 * @returns {Promise<unknown>} Promise per controllare se il server (servlet) sia accessibile
 */
function recuperaDati() {
    return new Promise((resolve, reject) => {
        fetch("http://serverfapakslapa.myddns.me/recuperaJson.php")
            .then((element) => {
                resolve(element.json());
            })
            .catch((error) => reject(error));
    });
}

/**
 * Funzione per selezionare solo i valori scelti
 * @param chiave scelta tra i vari valori possibili (temperatura, umidità, pioggia)
 * @returns {*[]} array creato con solo i valori scelti
 */
function creaArray(chiave) {
    let array = [];
    for (let i = 0; i < dict.length; i++) {
        for (let k = 0; k < Object.keys(dict[i]).length; k++) {
            if (Object.keys(dict[i])[k] === chiave) array.push(Object.values(dict[i])[k]);
        }
    }
    return array;
}

/**
 * Funzione per creare la media di un array
 * @param array array in ingresso per calcolarene la media
 * @returns {number} Media di valori
 */
function calcolaMedia(array) {
    let sum = 0;
    for (let i = 0; i < array.length; i++) {
        sum += parseFloat(array[i]);
    }

    return sum / array.length;
}

/**
 * Funzione che disegna i grafico a linee dell'evoluzione dei dati
 * @param array array contenente i dati
 * @param scritta cosa scrivere nel canvas
 * @param larghezzaLinea larghezza della linea del grafico
 * @param colore colore della linea
 * @param ctx dato per scegliere dove disegnare
 * @param canvas dato per scegliere dove disegnare
 */
function disegnaGrafico(array, scritta, larghezzaLinea, colore, ctx, canvas) {
    ctx.fillStyle = "#202428";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    let inizio = 0;
    const max = Math.max(...array);
    const unita = (canvas.height / 2 - ((canvas.height / 2) * 10) / 100) / max;
    let larghezza = canvas.width / (array.length - 1);
    ctx.lineWidth = larghezzaLinea;
    ctx.strokeStyle = colore;
    for (let i = 0; i < array.length - 1; i++) {
        ctx.beginPath();
        ctx.moveTo(inizio, canvas.height - array[i] * unita);
        inizio += larghezza;
        ctx.lineTo(inizio, canvas.height - array[i + 1] * unita);
        ctx.stroke();
    }
    let myFont = new FontFace("myFont", "url(Nexa.ttf)");
    myFont.load().then(function (font) {
        // with canvas, if this is ommited won't work
        document.fonts.add(font);
        ctx.font = "30px myFont"; // set font
        ctx.fillStyle = colore;
        ctx.textAlign = "left"; // center text
        ctx.fillText(array[array.length - 1] + scritta, canvas.width / 2 - canvas.width / 2.5, canvas.height / 2 - canvas.height / 5);
    });
}

/**
 * Funzione per disegnare solo l'ultimo dato e controllarlo rispetto alla media
 * @param array con tutti i valori
 * @param scritta da aggiungere alla fine del numero (es: °C)
 * @param colore della scritta
 * @param ctx dato per scegliere dove disegnare
 * @param canvas dato per scegliere dove disegnare
 */
function disegnaDati(array, scritta, colore, ctx, canvas) {
    ctx.fillStyle = "#202428";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    const media = calcolaMedia(array);
    let myFont = new FontFace("myFont", "url(Nexa.ttf)");
    myFont.load().then(function (font) {
        // with canvas, if this is ommited won't work
        document.fonts.add(font);
        ctx.font = "50px myFont"; // set font
        ctx.fillStyle = colore;
        ctx.textAlign = "center"; // center text
        ctx.fillText(array[array.length - 1] + scritta, canvas.width / 2, canvas.height / 2);
        let img = new Image();
        img.onload = function () {
            ctx.drawImage(img, canvas.width / 2 - canvas.width / 2.5 / 2, canvas.height / 2 + canvas.height / 20, canvas.width / 10, canvas.width / 10);
            ctx.font = "15px myFont"; // set font
            ctx.fillText(Number.parseFloat(media).toFixed(2) + scritta, canvas.width / 2, canvas.height / 2 + canvas.height / 5);
        };
        if (media > array[array.length - 1]) img.src = "down.svg"; else img.src = "up.svg";
    });
}

/**
 * Funzione per disegnare il meteo attuale
 * @param array con tutti i valori
 * @param ctx dato per scegliere dove disegnare
 * @param canvas dato per scegliere dove disegnare
 */
function disegnaPioggia(array, ctx, canvas) {
    ctx.fillStyle = "#202428";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    let img = new Image();
    img.onload = function () {
        ctx.drawImage(img, canvas.width / 2 - canvas.width / 2.5 / 2, canvas.height / 2 - canvas.width / 2.5 / 2, canvas.width / 2.5, canvas.width / 2.5);
    };
    if (array[array.length - 1] >= 980) img.src = "sole.svg"; else img.src = "tempesta.svg";
}

/**
 * Funzione per recuperare l'ultimo orario di aggiornamento dell'arduino
 * @returns {Promise<unknown>} promise per controllare se il server è accessibile
 */
function recuperaOrario() {
    return new Promise((resolve, reject) => {
        fetch("http://serverfapakslapa.myddns.me/controllaOrario/leggiFile.php")
            .then((element) => {
                resolve(element.json());
            })
            .catch((error) => reject(error));
    });
}

/**
 * Funzione per scrivere l'ultimo aggiornamento di arduino
 * @param ora dell'ultimo aggiornamento
 * @param minuto dell'ultimo aggiornamento
 * @param secondo dell'ultimo aggiornamento
 * @param giorno dell'ultimo aggiornamento
 * @param mese dell'ultimo aggiornamento
 * @param anno dell'ultimo aggiornamento
 */
function creaAggiornamento(ora, minuto, secondo, giorno, mese, anno) {
    const time1 = formatDate(new Date()).split(" ");
    const time = time1[1].split(":");
    if (time[0] > ora)
        update.innerText = "L'irrigatore è spento, le modifiche saranno attive alla prossima accensione";
    else
        update.innerText = "Le modifiche saranno attive dalle: \n" + ora + ":" + minuto + ":" + secondo + " " + giorno + "/" + mese + "/" + anno;
}

/**
 * Funzione per formattare la data
 * @param date data passata
 * @returns {string} data formattata
 */
function formatDate(date) {
    return ([date.getFullYear(), padTo2Digits(date.getMonth() + 1), padTo2Digits(date.getDate())].join("-") + " " + [padTo2Digits(date.getHours()), padTo2Digits(date.getMinutes())].join(":"));
}

/**
 * Funzione per avere solo 2 cifre decimali
 * @param num in ingresso da arrotondare
 * @returns {string} numero arrotondato
 */
function padTo2Digits(num) {
    return num.toString().padStart(2, "0");
}

/**
 * Funzione per recuperare il numero di immagini scattate dall'esp32
 * @returns {Promise<unknown>} promise per vedere se il server è accessibile
 */
function recuperaNumImg() {
    return new Promise((resolve, reject) => {
        fetch("http://serverfapakslapa.myddns.me/numeroImmagini.php")
            .then((element) => {
                resolve(element.json());
            })
            .catch((error) => reject(error));
    });
}

/**
 * Funzione per creare il carosello di immagini
 * @param numIniziale numero totale di immagini
 */
function creaCarosello(numIniziale) {
    const numTotale = numIniziale;
    let body = "";
    for (let i = 0; i < numTotale; i++) {
        body += controlImg.replace("%NUM1", String(i + 1));
        if (i + 1 !== numTotale)
            body = body.replace("%NUM2", String(i + 2));
        else
            body = body.replace("%NUM2", String(1));

        body = body.replace("%SECONDI", String(i + 1));
        if (i === 0) body = body.replace("%CLASS", "active"); else body = body.replace("%CLASS", "");
    }
    html += caruselBody.replace("%BODY", body);
    divCarosello.innerHTML = html;
}

/**
 * Funzione per il tasto irriga subito, richiama sul server una api
 * @returns {Promise<unknown>} Promise per vedere se il server è accessibile
 */
function scriviFile() {
    return new Promise((resolve, reject) => {
        fetch("http://serverfapakslapa.myddns.me/irrigaSubito/scriviFile.php")
            .then(() => {
                resolve();

            })
            .catch((error) => reject(error));
    });
}

/**
 * Funzione per recuperare il JSON contenente i nomi dei database, per poterli resettare
 * @returns {Promise<unknown>} Restituisce una promise per vedere se il server è accessibile
 */
function recuperaName() {
    return new Promise((resolve, reject) => {
        fetch("http://serverfapakslapa.myddns.me/resetDb/nomeDB.php")
            .then((element) => {
                resolve(element.json());
            })
            .catch((error) => reject(error));
    });
}

/**
 * Funzione per creare la serie di input check per resettare i vari db, utilizza una form
 * @param array di nomi dei database
 */
function creaReset(array) {
    let html = '<form action="http://serverfapakslapa.myddns.me/resetDb/checkDB.php" method="post">\n'; //http://serverfapakslapa.myddns.me/resetDb/
    for (let i = 0; i < array.length; i++) {
        html += checkTemplate.replace("%NAME", array[i]);
        html = html.replace("%ID", array[i]);
        html = html.replace("%IDLABEL", array[i]);
        html = html.replace("%DESCRIZIONE", array[i]);
    }
    html += '<button type="submit" class="btn btn-outline-primary">\n' +
        '<img src="done.svg" alt=""/>\n' +
        '</button></form>'
    divReset.innerHTML = html;
}

/**
 * Richiamo della funzione per recuperare i dati e delle funzioni per disegnare i grafici
 */
recuperaDati()
    .then((response) => {
        dict = response;
        disegnaDati(creaArray("temperatura"), "°C", "#f49237", ctxTemperatura, canvasTemperatura);
        disegnaDati(creaArray("umidita"), "%", "#a445db", ctxUmidita, canvasUmidita);
        disegnaPioggia(creaArray("piove"), ctxPioggia, canvasPioggia);
        /**
         * Nel caso venga premuto il bottone cambia modalità di visualizzazione
         */
        bottoneTemperatura.onclick = () => {
            boolTemperatura = !boolTemperatura;
            if (boolTemperatura) {
                disegnaGrafico(creaArray("temperatura"), "°C", 2, "#f49237", ctxTemperatura, canvasTemperatura);
            } else {
                disegnaDati(creaArray("temperatura"), "°C", "#f49237", ctxTemperatura, canvasTemperatura);
            }
        };
        /**
         * Nel caso venga premuto il bottone cambia modalità di visualizzazione
         */
        bottoneUmidita.onclick = () => {
            boolUmidita = !boolUmidita;
            if (boolUmidita) {
                disegnaGrafico(creaArray("umidita"), "%", 2, "#a445db", ctxUmidita, canvasUmidita);
            } else {
                disegnaDati(creaArray("umidita"), "%", "#a445db", ctxUmidita, canvasUmidita);
            }
        };
    })
    .catch((error) => console.log(error));

/**
 * Richiamo dei toast per istruzioni d'utilizzo
 */
bottoneHelp.onclick = () => {
    divHelp.innerHTML = stringaAiuto;
};

/**
 * Richiamo funzione per il recupero di immagini e funzioni per disegno
 */
recuperaNumImg()
    .then((response) => {
        creaCarosello(Number(Object.values(response)[0]));
    })
    .catch((error) => console.log(error + "img"));

/**
 * Richiamo funzione per scrivere su file
 */
buttonIrriga.onclick = () => {
    scriviFile()
        .then(() => {
        })
        .catch((error) => console.log(error + " errore"));
};

/**
 * Richiamo funzione per reset dei db
 */
recuperaName()
    .then((response) => {
        creaReset(response);
    })
    .catch((error) => console.log(error));

/**
 * Richiamo funzione per recupero dell'orario e per disegno ultimo update
 */
recuperaOrario()
    .then((response) => {
        const array = Object.values(response)[0].split("-");
        const orario = array[2].split(" ");
        let array2 = orario[1].split(":");
        creaAggiornamento(Number(array2[0]) + 1, array2[1], array2[2], array[0], array[1], orario[0]);

    })
    .catch((error) => console.log(error + "img"));