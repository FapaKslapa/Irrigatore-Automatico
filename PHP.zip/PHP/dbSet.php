<?php
// Configura la connessione al database MySQL
$server = "localhost"; // Indirizzo del server MySQL
$username = "root"; // Nome utente del database
$password = "123Stella"; // Password del database
$db = "vacanze"; // Nome del database

// Connettiti al database MySQL
$conn = new mysqli($server, $username, $password, $db);

$_SERVER["REQUEST_METHOD"] == "POST" ?  $dati = $_POST: $dati = $_GET;
//recupero il value dei dati 
$orario = $dati['orario'];
$gradi = $dati['gradi'];
$quantita = $dati['quantita'];
$lunedi = $dati['lunedi'] == "innaffia"  ? "si":"no";
$martedi = $dati['martedi']== "innaffia" ? "si":"no";
$mercoledi = $dati['mercoledi']== "innaffia" ? "si":"no";
$giovedi = $dati['giovedi']== "innaffia" ? "si":"no";
$venerdi = $dati['venerdi']== "innaffia" ? "si":"no";
$sabato = $dati['sabato']== "innaffia" ? "si":"no";
$domenica = $dati['domenica']== "innaffia" ? "si":"no";
$pioggia = $dati['pioggia'];
//eseguo i comandi sql
$sqldel = "DELETE FROM setinnaffiatore;";
$sql = "INSERT INTO setinnaffiatore (orario, gradi, pioggia,mlacqua, lunedi, martedi, mercoledi, giovedi, venerdi, sabato, domenica) VALUES ('" . $orario ."','". $gradi ."','". $pioggia ."','".$quantita."','". $lunedi."','" .$martedi."','".$mercoledi."','".$giovedi."','".$venerdi."','".$sabato."','".$domenica."')";
$conn->query($sqldel);
$conn->query($sql);
//reindirizzamento
header("Location: http://serverfapakslapa.myddns.me/areaPersonale/progettoEstivo");
 exit;
// Chiudi la connessione al database
$conn->close();
?>