<?php
header('Access-Control-Allow-Origin: *');
// URL della servlet Java
$url = 'http://serverfapakslapa.myddns.me:81/recuperaJSON_war/hello-servlet';

// Inizializza la sessione cURL, utilizzata per fare richieste http a servizi online, in questo caso alla servlet pubblicata con tomcat
$ch = curl_init(); 

// Imposta le opzioni per la richiesta POST
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);

// Esegui la richiesta cURL e memorizza la risposta
$response = curl_exec($ch);

// Chiudi la sessione cURL
curl_close($ch); 
echo $response;//restituisce il json ottenuto dalla servlet
?>