<?php
function criptaPassword($password){
$arrayAscii = [];
$arrayProdotto = [];
$criptata = "";
for($i=0;$i<strlen($password);$i++){
    $unicodeValue = mb_ord($password[$i], 'UTF-8');
    $arrayAscii[$i] =  $unicodeValue;
}
$codiceUnivoco = intval($arrayAscii[count($arrayAscii)-1]);
for($i=0;$i<strlen($password);$i++){
    if(intval($arrayAscii[$i])+$codiceUnivoco>255)
        $arrayProdotto[$i] = intval($arrayAscii[$i]) + $codiceUnivoco - 255;
    else
        $arrayProdotto[$i] = intval($arrayAscii[$i]) + $codiceUnivoco;
}
for($i=0;$i<count($arrayProdotto);$i++){
    $criptata .= mb_chr($arrayProdotto[$i]);
}
return $criptata;
}
// Include la classe PHPMailer
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Configura la connessione al database MySQL
$server = "localhost"; // Indirizzo del server MySQL
$username = "root"; // Nome utente del database
$password = "123Stella"; // Password del database
$db = "vacanze"; // Nome del database
// Connettiti al database MySQL
$conn = new mysqli($server, $username, $password, $db);
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$dati = $_POST;
$nome = $dati['nome'];
$email = $dati['email'];
$Password = $dati['password'];
$query = "SELECT * FROM utenti WHERE nomeUtente = '$email'";
$result = mysqli_query($conn, $query);
if ($result && mysqli_num_rows($result) > 0) {
    header("Location: http://serverfapakslapa.myddns.me/areaPersonale/registrati.html");
   exit;
} else {
   $sql = "INSERT INTO utenti (nome, nomeUtente, password) VALUES ('". $nome ."','". $email ."','". criptaPassword($Password) ."')";
   $conn->query($sql);
   $conn->close();
   // Crea una nuova istanza di PHPMailer
   $mail = new PHPMailer;

   // Imposta il debug a true per visualizzare eventuali errori
   $mail->SMTPDebug = 3;

   // Imposta il tipo di server SMTP
   $mail->isSMTP();

   // Imposta l'hostname del server SMTP di Gmail
   $mail->Host = 'smtp.gmail.com';

   // Imposta la porta SMTP per Gmail
   $mail->Port = 587;

   // Imposta il tipo di crittografia
   $mail->SMTPSecure = 'tls';

   // Imposta l'autenticazione SMTP
   $mail->SMTPAuth = true;

   // Imposta le credenziali del tuo account Gmail
   $mail->Username = 'irrigatoreautomatico@gmail.com';
   $mail->Password = 'iqiy wobs lwfg srai';//password generata per l'applicazione

   // Imposta il mittente
   $mail->setFrom('irrigatoreautomatico@gmail.com', 'Irrigatore Automatico');

   // Aggiunge un destinatario
   $mail->addAddress($email, $nome);

   // Imposta l'oggetto dell'email
   $mail->Subject = 'Conferma di registrazione';

   // Imposta il corpo dell'email in formato HTML
   $mail->isHTML(true);
   $messaggio = "<p>Benvenuto nel sito,<br> Ecco le tue credenziali</p>";
   $messaggio .= "<p><b>Nome utente: </b>$nome</p>";
   $messaggio .= "<p><b>Email: </b>$email</p>";
   $messaggio .= "<p><b>Password: </b>".$Password."</p>";
   $mail->Body = $messaggio;
   //$mail->Body = "<p>Ciao Stefano come sta andando arduino e l'esp?.</p>";
   //$mail->Body = "<footer>Email inviata esclusivamente al destinatario.</footer>";
   // Invia l'email e controlla se è stata inviata correttamente
   if (!$mail->send()) {
       echo 'Message could not be sent.';
       echo 'Mailer Error: ' . $mail->ErrorInfo;
   } else {
       echo 'Message has been sent.';
   }
   header("Location: http://serverfapakslapa.myddns.me/areaPersonale/progettoEstivo");
   exit;
}
}
?>