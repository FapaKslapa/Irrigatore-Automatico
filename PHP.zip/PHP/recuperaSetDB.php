<?php
// Configura la connessione al database MySQL
$server = "localhost"; // Indirizzo del server MySQL
$username = "root"; // Nome utente del database
$password = "123Stella"; // Password del database
$db = "vacanze"; // Nome del database

// Connettiti al database MySQL
$conn = new mysqli($server, $username, $password, $db);
//recupero dei valori delle variabili
$sql = "SELECT * FROM setinnaffiatore";
$result = mysqli_query($conn, $sql);//fa la query

$json = [];//definizione dell'array 
//legge le singole righe e le restituisce come array
while($row =  mysqli_fetch_assoc($result)){
    $json[] = $row;
}
    echo json_encode($json);//partendo dall'array creato lo restituisce in formato json
?>