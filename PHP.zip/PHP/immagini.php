<?php
// Cartella di destinazione dove verrà salvata l'immagine
$cartellaDestinazione = "D:/xampp/htdocs/immaginiSalvate/";
$immagine = $_SERVER["REQUEST_METHOD"] == "POST" ? $_POST['immagine'] : $_GET['immagine'];//tipologia di richiesta

$immagineDecodificata = base64_decode(str_replace(' ', '+', $immagine));//sostituisco gli spazi con i + e poi decodifico la stringa ottenuta
if (!file_exists("counter.txt")) {
    $file = fopen("counter.txt", "w");
    $num = 0;
} else {
    $file = fopen("counter.txt", "r+");
    $num = fgets($file, 20);
    fseek($file, 0);
}
$num = $num + 1;
print("Immagine num: " . $num);

$nomeImmagine = "immmagine" . $num . ".jpg";//generazione del nome dell'immagine con estensione jpg
fputs($file, $num);
fclose($file);
$percorsoCompleto = $cartellaDestinazione . $nomeImmagine;//genero il percorso completo
file_put_contents($percorsoCompleto, $immagineDecodificata);//salvo l'immagine nel percorso specificato
?>
