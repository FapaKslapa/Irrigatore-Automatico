<!DOCTYPE html>
<html>
  <head>
    <title>Salva link</title>
    <meta charset="UTF-8" />
    <link href="https://fonts.cdnfonts.com/css/mont" rel="stylesheet" />

    <link rel="stylesheet" href="src/styles.css" />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link href="https://fonts.cdnfonts.com/css/coolvetica" rel="stylesheet" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <?php 
      // Configura la connessione al database MySQL
      $server = "localhost"; // Indirizzo del server MySQL
      $username = "root"; // Nome utente del database
      $password = ""; // Password del database
      $db = "vacanze"; // Nome del database

      // Connettiti al database MySQL
      $conn = new mysqli($server, $username, $password, $db);

      // Verifica se la richiesta è di tipo POST
      if ($_SERVER["REQUEST_METHOD"] == "POST") {
        //se è una richiesta post allora invia i dati al db per la loro memorizzazione
          // Ottieni i dati inviati da Arduino
          $dati = $_POST;
          $sql = "INSERT INTO linkutili (descrizione, link) VALUES ('" .$dati['descrizione']. "','" .$dati['link']. "')";
          $conn->query($sql);
          $conn->close();
      }else if ($_SERVER["REQUEST_METHOD"] == "GET"){
        //se è una richiesta get allora elimina dal db il link in base alla descrizione inserita
        $dati = $_GET;
        $descrizioneLink = $dati['descrizione'];
        $sql = "DELETE FROM `linkutili` WHERE descrizione='". $dati['descrizione'] ."'";
        // Esegui l'istruzione SQL
        $conn->query($sql);
        $conn->close();
      }
    ?>

  </head>
  <body background="./sfondo.jpg">
    <div class="cointainer">
      <h1>
        > Salva i link per visualizzarli
      </h1>
      <form
        action="<?php echo $_SERVER['PHP_SELF']; ?>"
        method="post"
        class="row g-3"
      >
        <div class="col-md-6">
          <input
            type="text"
            placeholder="descrizione"
            id="descrizione"
            name="descrizione"
            class="form-control"
          />
        </div>
        <div class="col-md-6">
          <input
            type="url"
            placeholder="link"
            id="link"
            name="link"
            class="form-control"
          />
        </div>
        <div class="col-12">
          <button type="submit" id="confermaL" name="conferma" class="btn btn-primary">
            Invia
          </button>
        </div>
      </form>
      <h1>
        > Inserisci la descrizione del link da eliminare
      </h1>
      <form
        action="<?php echo $_SERVER['PHP_SELF']; ?>"
        method="get"
        class="row g-3"
      >
        <div class="col-12">
          <input
            type="text"
            placeholder="descrizione link da eliminare"
            id="descrizione"
            name="descrizione"
            class="form-control"
          />
        </div>
        <div class="col-12">
          <button type="submit" class="btn btn-primary">Invia</button>
        </div>
      </form>
    </div>
  </body>
</html>
