<?php
function criptaPassword($password){
    $arrayAscii = [];
    $arrayProdotto = [];
    $criptata = "";
    for($i=0;$i<strlen($password);$i++){
        $unicodeValue = mb_ord($password[$i], 'UTF-8');
        $arrayAscii[$i] =  $unicodeValue;
    }
    $codiceUnivoco = intval($arrayAscii[count($arrayAscii)-1]);
    for($i=0;$i<strlen($password);$i++){
        if(intval($arrayAscii[$i])+$codiceUnivoco>255)
            $arrayProdotto[$i] = intval($arrayAscii[$i]) + $codiceUnivoco - 255;
        else
            $arrayProdotto[$i] = intval($arrayAscii[$i]) + $codiceUnivoco;
    }
    for($i=0;$i<count($arrayProdotto);$i++){
        $criptata .= mb_chr($arrayProdotto[$i]);
    }
    return $criptata;
}
// Include la classe PHPMailer
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Configura la connessione al database MySQL
$server = "localhost"; // Indirizzo del server MySQL
$username = "root"; // Nome utente del database
$password = "123Stella"; // Password del database
$db = "vacanze"; // Nome del database
$con = new mysqli($server, $username, $password, $db);//connessione al db

if($_SERVER["REQUEST_METHOD"] == "POST" ){
    $dati = $_POST;
    //recupero i dati
    $nomeUtente = $dati['email'];
    $Password = $dati['password'];
    //query
    $query = 'SELECT * FROM utenti WHERE nomeUtente = "'.$nomeUtente.'"';
    $update = "UPDATE utenti SET password = '" .criptaPassword($Password). "' WHERE nomeUtente ='". $nomeUtente."'";
    $result = mysqli_query($con, $query);
  //Se non c'è nessun nome utente inserito
  if ($result && mysqli_num_rows($result) > 0){
    $con->query($update);
    
    $con->close();
    // Crea una nuova istanza di PHPMailer
    $mail = new PHPMailer;

    // Imposta il debug a true per visualizzare eventuali errori
    $mail->SMTPDebug = 3;

    // Imposta il tipo di server SMTP
    $mail->isSMTP();

    // Imposta l'hostname del server SMTP di Gmail
    $mail->Host = 'smtp.gmail.com';

    // Imposta la porta SMTP per Gmail
    $mail->Port = 587;

    // Imposta il tipo di crittografia
    $mail->SMTPSecure = 'tls';

    // Imposta l'autenticazione SMTP
    $mail->SMTPAuth = true;

    // Imposta le credenziali del tuo account Gmail
    $mail->Username = 'irrigatoreautomatico@gmail.com';
    $mail->Password = 'iqiy wobs lwfg srai';//password generata per l'applicazione

    // Imposta il mittente
    $mail->setFrom('irrigatoreautomatico@gmail.com', 'Irrigatore Automatico');

    // Aggiunge un destinatario
    $mail->addAddress($nomeUtente, '');

    // Imposta l'oggetto dell'email
    $mail->Subject = 'Richiesta cambio password';

    // Imposta il corpo dell'email in formato HTML
    $mail->isHTML(true);
    $messaggio = "<p>Password cambiata con successo. Ecco le tue nuove credenziali:</p>";
    $messaggio .= "<p><b>Email: </b>$nomeUtente</p>";
    $messaggio .= "<p><b>Nuova password: </b>$Password</p>";
    $mail->Body = $messaggio;
    // Invia l'email 
    $mail->send();
        header("Location: http://serverfapakslapa.myddns.me/areaPersonale");
    }
  }
?>
<html>
  <head>
    <title>Registrati</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link
      href="https://fonts.cdnfonts.com/css/aliens-and-cows"
      rel="stylesheet"
    />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link href="https://fonts.cdnfonts.com/css/coolvetica" rel="stylesheet" />
    <link rel="stylesheet" href="src/registrati.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  </head>
  <body background="sfondo.jpg">
    <h1>MODIFICA LA PASSWORD</h1>
    <div class="container">
      <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <div class="row">
          <div class="col">
            <div class="form-floating">
              <input
                class="form-control"
                type="email"
                id="email"
                value=""
                name="email"
                placeholder="Inserisci la mail"
                required
              />
              <label for="nomeUtente"
                >Email
                <img
                  src="email.svg"
                  alt=""
                  width="30"
                  height="24"
                  class="d-inline-block align-text-center"
              /></label>
            </div>
          </div>
          <div class="col">
            <div class="input-group mb-3">
              <div class="form-floating">
                <input
                  type="password"
                  class="form-control"
                  name="password"
                  id="password"
                  placeholder="Nuova password"
                  required
                />
                <label for="password"
                  >Nuova password
                  <img
                    src="password.svg"
                    alt=""
                    width="30"
                    height="24"
                    class="d-inline-block align-text-center"
                /></label>
              </div>
              <button
                type="button"
                class="btn btn-primary btn-lg"
                id="guarda"
                value="Visualizza"
              >
                <img
                  src="guarda.svg"
                  alt=""
                  width="30"
                  height="24"
                  class="d-inline-block align-text-center"
                />
              </button>
            </div>
          </div>
        </div>
        <br />
        <br />
        <br />
        <br />
        <button
          class="btn btn-primary btn-containerRight"
          type="submit"
          value="invia"
          id="registrati"
        >
          Cambia password<img
            src="accedi.svg"
            alt=""
            width="30"
            height="24"
            class="d-inline-block align-text-center"
          />
        </button>
      </form>
      <form
        action="http://serverfapakslapa.myddns.me/areaPersonale"
        method="post"
      >
        <button
          class="btn btn-primary btn-containerLeft"
          type="submit"
          value="Indietro"
        >
          Indietro
          <img
            src="indietro.svg"
            alt=""
            width="30"
            height="24"
            class="d-inline-block align-text-center"
          />
        </button>
      </form>

<script src="src/cambia.js"></script>
</body>
</html>