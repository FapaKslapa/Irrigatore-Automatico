<?php
header('Access-Control-Allow-Origin: *');
$nomeFile = "dataOra.txt";
$giornoOra = date("d-m-Y H:i:s");
$handler = fopen($nomeFile, 'w');//crea il file e lo apre in scrittura o lo apre in scrittura
fwrite($handler, $giornoOra);//scrivo true al suo interno
fclose($handler);//chiusura del file


?>