<?php
header('Access-Control-Allow-Origin: *');
$giornoOra = date("d-m-Y H:i:s");//recupero data ed ora
$separati = explode(" ", $giornoOra);//split
//restituisco un json
echo json_encode(array(
    "giorno" => $separati[0],
    "ora" => $separati[1]
    ));
?>