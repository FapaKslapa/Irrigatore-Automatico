<?php
header('Access-Control-Allow-Origin: *');
$nomeFile = "dataOra.txt";
if (file_exists($nomeFile)) {//se esiste lo legge e restituisce il valore memorizzato
    $handler = fopen($nomeFile, "r");//apertura del file in lettura
    $lettura = fread($handler, 100);//lettura del file
    fclose($handler);//chiusura del file
    echo json_encode(array("dataOra" => $lettura));
} else {
    $giornoOra = date("d-m-Y H:i:s");//recupero data ed ora
    $handler = fopen($nomeFile, 'w');//crea il file e lo apre in scrittura o lo apre in scrittura
    fwrite($handler, $giornoOra);//scrivo la data ed ora al suo interno
    fclose($handler);//chiusura del file 
    echo json_encode(array("dataOra" => $giornoOra));
}
?>