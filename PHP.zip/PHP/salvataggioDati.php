<?php
header('Access-Control-Allow-Origin: *');

// Configura la connessione al database MySQL
$server = "localhost"; // Indirizzo del server MySQL
$username = "root"; // Nome utente del database
$password = "123Stella"; // Password del database
$db = "vacanze"; // Nome del database

// Connettiti al database MySQL
$conn = new mysqli($server, $username, $password, $db);

$_SERVER["REQUEST_METHOD"] == "POST" ?  $dati = $_POST :  $dati = $_GET;//verifica del tipo di richiesta

//controllo dei valori, se non viene passato nessun valore viene inserito il valore 0
$temperatura = $dati['campo1'] != ""  ? $dati['campo1'] : 0;
$umidità = $dati['campo2'] != ""  ? $dati['campo2'] : 0;
$piove = $dati['campo3'] != ""  ? $dati['campo3'] : 0;
$currentDateTime = date('Y-m-d H:i:s');//data ed ora 
// Esegui l'inserimento dei dati nel database
$sql = "INSERT INTO rilevazionimeteo (DATA_ORA, TEMPERATURA, UMIDITA, PIOVE) VALUES ('" . $currentDateTime . "','" . $temperatura . "', '" . $umidità . "', '" . $piove. "')";
$conn->query($sql);
// Chiudi la connessione al database
$conn->close();
?>