<?php

function criptaPassword($password){
    $arrayAscii = [];
    $arrayProdotto = [];
    $criptata = "";
    for($i=0;$i<strlen($password);$i++){
        $unicodeValue = mb_ord($password[$i], 'UTF-8');
        $arrayAscii[$i] =  $unicodeValue;
    }
    $codiceUnivoco = intval($arrayAscii[count($arrayAscii)-1]);
    for($i=0;$i<strlen($password);$i++){
        if(intval($arrayAscii[$i])+$codiceUnivoco>255)
            $arrayProdotto[$i] = intval($arrayAscii[$i]) + $codiceUnivoco - 255;
        else
            $arrayProdotto[$i] = intval($arrayAscii[$i]) + $codiceUnivoco;
    }
    for($i=0;$i<count($arrayProdotto);$i++){
        $criptata .= mb_chr($arrayProdotto[$i]);
    }
    return $criptata;
}
// Configura la connessione al database MySQL
$server = "localhost"; // Indirizzo del server MySQL
$username = "root"; // Nome utente del database
$password = "123Stella"; // Password del database
$db = "vacanze"; // Nome del database
// Connettiti al database MySQL
$conn = new mysqli($server, $username, $password, $db);

$dati = $_SERVER["REQUEST_METHOD"] == "POST" ? $_POST : $_GET;//tipologia di richiesta
$nomeUtente = $dati['nomeUtente'];
$Password = $dati['password'];
//oerazioni sul db
$query = "SELECT * FROM utenti WHERE nomeUtente = '$nomeUtente' AND password='".criptaPassword($Password)."'";
$result = mysqli_query($conn, $query);
if ($result && mysqli_num_rows($result) > 0) 
    header("Location: http://serverfapakslapa.myddns.me/areaPersonale/progettoEstivo");
else
    header("Location: http://serverfapakslapa.myddns.me/areaPersonale");

?>