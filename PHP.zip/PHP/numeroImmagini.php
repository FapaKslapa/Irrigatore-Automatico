<?php
header('Access-Control-Allow-Origin: *');
$array_file = glob("immaginiSalvate/*.jpg", GLOB_BRACE);  //crea un array contenente i path delle immagini
echo json_encode(array("numero immagini"=>count($array_file))); //restituisco la grandezza dell'array
?>