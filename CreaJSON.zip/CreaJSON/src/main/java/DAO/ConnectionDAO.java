package DAO;

import Model.Rilevazioni;

import java.util.ArrayList;

public interface ConnectionDAO {
    ArrayList<Rilevazioni> selectAll() throws Exception;
}
