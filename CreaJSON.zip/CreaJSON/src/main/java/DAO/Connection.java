package DAO;


import Model.Rilevazioni;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * @author FapaKslapa & Ciro A. Strazzullo
 */
public class Connection implements ConnectionDAO {
    private final String USER = "root";
    private final String PASSWORD = "123Stella";
    private final String URL = "jdbc:mariadb://localhost:3306/vacanze";
    private java.sql.Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public Connection() {
    }

    /**
     * Creazione di una nuova connessione al database, date le credenziali
     *
     * @throws Exception Se la connessione non va a buon fine
     */
    private void getConnection() throws Exception {
        connection = DriverManager.getConnection(URL, USER, PASSWORD);
    }

    /**
     * Metodo per creare un arraylist di rilevazioni, con i dati memorizzati sul database
     *
     * @return arrayList di rilevazioni
     * @throws Exception nel caso la connessione cadesse
     */
    public ArrayList<Rilevazioni> selectAll() throws Exception {
        this.getConnection();
        this.statement = connection.createStatement();
        this.resultSet = statement.executeQuery("SELECT * FROM `rilevazionimeteo` ");
        ArrayList<Rilevazioni> ril = new ArrayList<>();
        while (resultSet.next()) {
            String dataOra, umidita, temperatura, piove;
            temperatura = resultSet.getString("TEMPERATURA");
            umidita = resultSet.getString("UMIDITA");
            piove = resultSet.getString("PIOVE");
            dataOra = resultSet.getString("DATA_ORA");
            Rilevazioni l = new Rilevazioni(temperatura, umidita, piove, dataOra);
            ril.add(l);

        }
        connection.close();
        statement.close();
        resultSet.close();
        return ril;
    }
}

