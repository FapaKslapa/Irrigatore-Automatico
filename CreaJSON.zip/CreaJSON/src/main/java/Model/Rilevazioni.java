package Model;

/**
 * @author FapaKslapa & Ciro A. Strazzullo
 */
public class Rilevazioni {
    private String temperature, umidita, piove, dataOra;

    /**
     * Costruttore per la classe rilevazioni, esso prende in ingresso tutti i dati del DB
     *
     * @param temperature temperatura rilevata
     * @param umidita     umidità rilevata
     * @param piove       pioggia rilevata
     * @param dataOra     dataOra della rilevazione
     */
    public Rilevazioni(String temperature, String umidita, String piove, String dataOra) {
        this.temperature = temperature;
        this.umidita = umidita;
        this.piove = piove;
        this.dataOra = dataOra;
    }

    public Rilevazioni() {
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getUmidita() {
        return umidita;
    }

    public void setUmidita(String umidita) {
        this.umidita = umidita;
    }

    public String getPiove() {
        return piove;
    }

    public void setPiove(String piove) {
        this.piove = piove;
    }

    public String getDataOra() {
        return dataOra;
    }

    public void setDataOra(String dataOra) {
        this.dataOra = dataOra;
    }

    /**
     * Metodo ToString() in Override, esso viene implementato per la stampa in console o, in questo caso, per la visualizzazione in JSON
     *
     * @return Stringa che verrà visualizzata in JSON
     */
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("{");
        sb.append("temperatura: '").append(temperature);
        sb.append(", umidita: '").append(umidita);
        sb.append(", piove: '").append(piove);
        sb.append(", dataOra: '").append(dataOra);
        sb.append('}');
        return sb.toString();
    }
}
