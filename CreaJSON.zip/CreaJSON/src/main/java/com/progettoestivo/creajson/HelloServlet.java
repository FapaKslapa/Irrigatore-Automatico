package com.progettoestivo.creajson;

import java.io.*;

import DAO.Connection;
import com.google.gson.Gson;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "helloServlet", value = "/hello-servlet")
public class HelloServlet extends HttpServlet {
    private String message;
    public Connection dati;
    public Gson gson;

    public void init() {
        gson = new Gson();
        dati = new Connection();
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        try {
            out.println(gson.toJson(dati.selectAll()));
            out.flush();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        try {
            out.println(gson.toJson(dati.selectAll()));
            out.flush();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void destroy() {
    }
}